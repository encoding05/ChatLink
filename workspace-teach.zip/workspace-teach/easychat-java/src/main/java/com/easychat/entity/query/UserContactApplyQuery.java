package com.easychat.entity.query;


/**
 *@ Description:用户联系人申请表
 *@ Date:2024/12/02
 */
public class UserContactApplyQuery extends BaseQuery {

	/**
	 *@ Description:自增ID查询对象
	 */
	private Integer applyId;

	/**
	 *@ Description:申请人ID查询对象
	 */
	private String applyUserId;

	private String applyUserIdFuzzy;

	/**
	 *@ Description:接收人ID查询对象
	 */
	private String receiveUserId;

	private String receiveUserIdFuzzy;

	/**
	 *@ Description:联系人类型 0:好友 1:群组查询对象
	 */
	private Integer contactType;

	/**
	 *@ Description:联系人ID或者群组ID查询对象
	 */
	private String contactId;

	private String contactIdFuzzy;

	/**
	 *@ Description:最后申请时间查询对象
	 */
	private Long lastApplyTime;

	/**
	 *@ Description:申请状态 0:待处理 1:已同意 2:已拒绝 3:已拉黑查询对象
	 */
	private Integer status;

	/**
	 *@ Description:申请信息查询对象
	 */
	private String applyInfo;

	private String applyInfoFuzzy;

	private Boolean queryContactInfo;

	private Long lastApplyTimestamp;

	public Long getLastApplyTimestamp() {
		return lastApplyTimestamp;
	}

	public void setLastApplyTimestamp(Long lastApplyTimestamp) {
		this.lastApplyTimestamp = lastApplyTimestamp;
	}

	public Boolean getQueryContactInfo() {
		return queryContactInfo;
	}

	public void setQueryContactInfo(Boolean queryContactInfo) {
		this.queryContactInfo = queryContactInfo;
	}

	public void setApplyId(Integer applyId) {
		this.applyId = applyId;
	}

	public Integer getApplyId() {
		return this.applyId;
	}

	public void setApplyUserId(String applyUserId) {
		this.applyUserId = applyUserId;
	}

	public String getApplyUserId() {
		return this.applyUserId;
	}

	public void setReceiveUserId(String receiveUserId) {
		this.receiveUserId = receiveUserId;
	}

	public String getReceiveUserId() {
		return this.receiveUserId;
	}

	public void setContactType(Integer contactType) {
		this.contactType = contactType;
	}

	public Integer getContactType() {
		return this.contactType;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getContactId() {
		return this.contactId;
	}

	public void setLastApplyTime(Long lastApplyTime) {
		this.lastApplyTime = lastApplyTime;
	}

	public Long getLastApplyTime() {
		return this.lastApplyTime;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setApplyInfo(String applyInfo) {
		this.applyInfo = applyInfo;
	}

	public String getApplyInfo() {
		return this.applyInfo;
	}

	public void setApplyUserIdFuzzy(String applyUserIdFuzzy) {
		this.applyUserIdFuzzy = applyUserIdFuzzy;
	}

	public String getApplyUserIdFuzzy() {
		return this.applyUserIdFuzzy;
	}

	public void setReceiveUserIdFuzzy(String receiveUserIdFuzzy) {
		this.receiveUserIdFuzzy = receiveUserIdFuzzy;
	}

	public String getReceiveUserIdFuzzy() {
		return this.receiveUserIdFuzzy;
	}

	public void setContactIdFuzzy(String contactIdFuzzy) {
		this.contactIdFuzzy = contactIdFuzzy;
	}

	public String getContactIdFuzzy() {
		return this.contactIdFuzzy;
	}

	public void setApplyInfoFuzzy(String applyInfoFuzzy) {
		this.applyInfoFuzzy = applyInfoFuzzy;
	}

	public String getApplyInfoFuzzy() {
		return this.applyInfoFuzzy;
	}

}